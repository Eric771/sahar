from .client import CHRLINE

# ORIGINAL LICENSE
__copyright__ = 'Copyright 2020-2021 by DeachSword'
__version__ = '2.0.7'
__license__ = 'BSD-3-Clause'
__author__ = 'DeachSword'
__url__ = 'http://github.com/DeachSword'

__all__ = ['CHRLINE']
